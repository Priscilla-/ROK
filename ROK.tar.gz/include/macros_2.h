/* SOME MACROS */

#include <malloc/malloc.h>
#include <stdio.h>
#include <stdlib.h>

#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))
#define SQR(a) ((a)*(a))

